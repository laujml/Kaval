# Kaval – código fuente de los mockups (HTML/CSS)

- `screens/*.html` – 13 pantallas (390×844), usan `styles.css`. Ábrelas en Chrome.
- `lib.py` – componentes: íconos, avatares e ilustraciones SVG originales (sin assets externos).
- `screens.py` – genera las pantallas (`python3 screens.py`).
- `render.sh` – renderiza a PNG @2x (780×1688) con Chrome headless en `../png/`.
- `boards.py` + `render_boards.sh` – tablero general y hero.
- `md_to_docx.py` – convierte los prompts de Stitch a Word.
Fuentes: Poppins (títulos) y Nunito (texto), Google Fonts instaladas localmente. Acento coral #FF6B4A.
