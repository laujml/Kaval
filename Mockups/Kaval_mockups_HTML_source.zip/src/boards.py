from lib import logo, beach, volcano, ic
from screens import SCREENS
FONTS = "<link rel='stylesheet' href='styles.css'>"
sw = [('#FF6B4A','Coral (acento)'),('#DFF5EB','Menta'),('#FFE9DE','Durazno'),('#FFF8F0','Crema'),('#1F2A3B','Tinta'),('#1FA971','Positivo'),('#E5484D','Debe')]
def swatches(size=34):
    return ''.join(f'<div style="display:flex;flex-direction:column;align-items:center;gap:6px"><div style="width:{size}px;height:{size}px;border-radius:12px;background:{c};box-shadow:inset 0 0 0 1px rgba(0,0,0,.06)"></div><span style="font-size:12px;font-weight:800;color:#5D6878">{c}</span></div>' for c,_ in sw)

def board():
    W = 330; H = int(W*844/390)
    cells = ''
    for i,(fn,title,_,_) in enumerate(SCREENS):
        off = 56 if i % 2 else 0
        cells += (f'<div style="width:{W}px;margin-top:{off}px"><img src="../png/{fn}.png" style="width:{W}px;height:{H}px;border-radius:40px;display:block;box-shadow:0 30px 60px rgba(31,42,59,.14),0 0 0 1px rgba(31,42,59,.04)">'
                  f'<div style="margin-top:16px;font-family:Poppins;font-weight:600;font-size:17px;color:#1F2A3B"><span style="color:#FF6B4A">{fn[:2]}</span> · {title}</div></div>')
    # style tile
    cells += (f'<div style="width:{W}px;margin-top:56px;height:{H}px;border-radius:40px;background:#fff;box-shadow:0 30px 60px rgba(31,42,59,.10);padding:34px 28px;display:flex;flex-direction:column;gap:22px">'
              f'<div style="display:flex;gap:12px;align-items:center">{logo(52)}<div><div style="font-family:Poppins;font-weight:700;font-size:26px">kaval</div><div style="font-size:13px;font-weight:700;color:#5D6878">Guía de estilo</div></div></div>'
              f'<div><div class="label">COLORES</div><div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px 6px">{swatches(46)}</div></div>'
              '<div><div class="label">TIPOGRAFÍA</div><div style="font-family:Poppins;font-weight:700;font-size:30px;letter-spacing:-.5px">Poppins Aa</div><div style="font-size:13px;color:#5D6878;font-weight:700">Títulos · 600/700</div>'
              '<div style="font-family:Nunito;font-weight:800;font-size:26px;margin-top:8px">Nunito Aa</div><div style="font-size:13px;color:#5D6878;font-weight:700">Texto y UI · 600/800</div></div>'
              '<div><div class="label">COMPONENTES</div><div style="display:flex;gap:8px;flex-wrap:wrap"><span class="chip on">Todos</span><span class="chip">🏖️ Playa</span><span class="tag g">+$85.40</span><span class="tag r">−$10.60</span><span class="pro">PRO</span></div>'
              f'<div style="display:flex;gap:10px;align-items:center;margin-top:14px"><div class="btn" style="flex:1;height:48px;font-size:14px">Confirmar</div><div style="width:52px;height:52px;border-radius:50%;background:#FF6B4A;display:flex;align-items:center;justify-content:center;box-shadow:0 10px 20px rgba(255,107,74,.4)">{ic("mic",24,"#fff")}</div></div></div>'
              '<div style="font-size:12.5px;color:#9BA4B1;font-weight:700;margin-top:auto">Radios 20–30 px · sombras suaves · ilustraciones planas SVG</div></div>')
    body = (f'<div style="position:absolute;left:-200px;top:-260px;width:900px;height:900px;border-radius:50%;background:#DFF5EB;opacity:.8"></div>'
            f'<div style="position:absolute;right:-240px;top:500px;width:1000px;height:1000px;border-radius:50%;background:#FFE9DE;opacity:.8"></div>'
            '<div style="position:relative;padding:90px 110px 0;display:flex;justify-content:space-between;align-items:flex-end">'
            f'<div style="display:flex;gap:26px;align-items:center">{logo(96)}<div><div style="font-family:Poppins;font-weight:700;font-size:64px;letter-spacing:-2px;line-height:1">Kaval</div>'
            '<div style="font-family:Poppins;font-weight:500;font-size:26px;color:#5D6878;margin-top:8px">Control de Gastos para Salidas y Viajes</div></div></div>'
            '<div style="text-align:right;font-size:18px;font-weight:700;color:#5D6878;line-height:1.6">UI Mockups · 13 pantallas · Flutter (iOS / Android)<br>Desarrollo de Aplicaciones Móviles · Laura Angel · El Salvador 🇸🇻<br><span style="color:#FF6B4A">Coral #FF6B4A</span> · Poppins + Nunito</div></div>'
            f'<div style="position:relative;display:flex;flex-wrap:wrap;gap:60px 44px;padding:70px 100px 110px">{cells}</div>')
    return (f'<!doctype html><html><head><meta charset="utf-8">{FONTS}<style>html,body{{width:2840px;height:auto;overflow:hidden;background:#FFF8F0}}</style></head><body>{body}</body></html>')

def hero():
    def ph(fn, w, style):
        h = int(w*844/390)
        return f'<img src="../png/{fn}.png" style="position:absolute;width:{w}px;height:{h}px;border-radius:{w*0.12:.0f}px;box-shadow:0 40px 80px rgba(31,42,59,.22),0 0 0 1px rgba(31,42,59,.05);{style}">'
    pills = ''.join(f'<span class="chip" style="height:44px;font-size:16px;padding:0 18px;color:#1F2A3B;background:#fff">{t}</span>' for t in ['🎙️ Gastos por voz','🤝 Quién le paga a quién','💵 Efectivo del grupo','📲 Resumen para WhatsApp','☁️ Funciona sin conexión'])
    body = ('<div style="position:absolute;inset:0;background:linear-gradient(120deg,#FFF8F0 0%,#FFE9DE 55%,#DFF5EB 100%)"></div>'
            '<div style="position:absolute;right:120px;top:90px;width:820px;height:820px;border-radius:50%;background:#fff;opacity:.55"></div>'
            '<div style="position:absolute;right:250px;top:200px;width:560px;height:560px;border-radius:50%;background:#DFF5EB"></div>'
            f'<div style="position:absolute;left:110px;top:150px;width:600px">'
            f'<div style="display:flex;gap:16px;align-items:center">{logo(68)}<span style="font-family:Poppins;font-weight:700;font-size:40px;letter-spacing:-1px">kaval</span></div>'
            '<div style="font-family:Poppins;font-weight:700;font-size:64px;line-height:1.08;letter-spacing:-2px;margin-top:36px;color:#1F2A3B">Viajen juntos,<br>cuentas <span style="color:#FF6B4A">claras</span> ✨</div>'
            '<div style="font-size:22px;font-weight:700;color:#5D6878;line-height:1.5;margin-top:22px;max-width:520px">Control de gastos para salidas y viajes en grupo. Dicta “pagué 24 dólares de gasolina por todos” y Kaval hace las cuentas.</div>'
            f'<div style="display:flex;flex-wrap:wrap;gap:10px;margin-top:30px;max-width:560px">{pills}</div>'
            '<div style="font-size:15px;font-weight:800;color:#9BA4B1;margin-top:34px">Flutter · iOS & Android · USD · Español / English</div></div>'
            + ph('07_dictar_gasto', 300, 'left:820px;top:200px;transform:rotate(-6deg)')
            + ph('09_liquidacion', 300, 'left:1300px;top:200px;transform:rotate(6deg)')
            + ph('03_inicio', 340, 'left:1040px;top:125px;z-index:3'))
    return (f'<!doctype html><html><head><meta charset="utf-8">{FONTS}<style>html,body{{width:1700px;height:1000px;overflow:hidden}}</style></head><body style="position:relative">{body}</body></html>')

open('board.html','w').write(board()); open('hero.html','w').write(hero()); print('ok')
