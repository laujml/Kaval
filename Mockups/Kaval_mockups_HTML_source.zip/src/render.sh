#!/bin/bash
# Render each screen HTML to PNG at 390x844 @2x using headless Chrome
cd "$(dirname "$0")"
OUT=../png; mkdir -p $OUT
for f in screens/*.html; do
  n=$(basename "$f" .html)
  google-chrome --headless=new --no-sandbox --disable-gpu --hide-scrollbars --force-device-scale-factor=2 \
    --window-size=390,844 --virtual-time-budget=1500 --screenshot="$OUT/$n.png" "file://$PWD/$f" >/dev/null 2>&1 &
done
wait
