"""Kaval mockups - shared components: icons, avatars, illustrations (all original inline SVG)."""
import itertools, math, random
_uid = itertools.count(1)
def uid(): return next(_uid)

ICONS = {
'home':'<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
'bag':'<rect x="3" y="7" width="18" height="13" rx="3"/><path d="M8 7V5.5A2.5 2.5 0 0 1 10.5 3h3A2.5 2.5 0 0 1 16 5.5V7M3 12.5h18"/>',
'clock':'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
'user':'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>',
'mic':'<rect x="9" y="2.5" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3.5"/>',
'plus':'<path d="M12 5v14M5 12h14"/>',
'back':'<path d="M15 5l-7 7 7 7"/>',
'close':'<path d="M6 6l12 12M18 6 6 18"/>',
'bell':'<path d="M6 16v-5a6 6 0 0 1 12 0v5l1.5 2h-15z"/><path d="M10 21h4"/>',
'check':'<path d="M5 12.5l4.5 4.5L19 7.5"/>',
'share':'<circle cx="18" cy="5" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="19" r="2.5"/><path d="M8.2 10.8l7.6-4.4M8.2 13.2l7.6 4.4"/>',
'copy':'<rect x="8" y="8" width="12" height="12" rx="3"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
'cloudcheck':'<path d="M7 18a4.5 4.5 0 0 1-.5-9A6 6 0 0 1 18 8.5 4.75 4.75 0 0 1 17.5 18z"/><path d="M9.5 13.2l2 2 3.5-3.5"/>',
'cloudoff':'<path d="M7 18a4.5 4.5 0 0 1-.5-9c.3-1.1.9-2.1 1.7-2.9M11 4.6A6 6 0 0 1 18 8.5a4.75 4.75 0 0 1 2.2 7.9M3 3l18 18M17.5 18H15"/>',
'arrow':'<path d="M5 12h14M13 6l6 6-6 6"/>',
'edit':'<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
'keyboard':'<rect x="2.5" y="6" width="19" height="12" rx="3"/><path d="M6.5 10h.01M10 10h.01M14 10h.01M17.5 10h.01M7.5 14h9"/>',
'globe':'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.7 3.5 5.7 3.5 9s-1 6.3-3.5 9c-2.5-2.7-3.5-5.7-3.5-9s1-6.3 3.5-9z"/>',
'crown':'<path d="M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5z"/>',
'trash':'<path d="M4 7h16M9 7V4.5h6V7M6 7l1 13h10l1-13"/>',
'wallet':'<rect x="3" y="6" width="18" height="14" rx="3"/><path d="M3 10h18M16 15h2"/>',
'link':'<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
'eye':'<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
'mail':'<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M4 7l8 6 8-6"/>',
'lock':'<rect x="4.5" y="10" width="15" height="11" rx="3"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
'calendar':'<rect x="3.5" y="5" width="17" height="16" rx="3"/><path d="M8 3v4M16 3v4M3.5 10h17"/>',
'users':'<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18 14c2.2.6 3.5 2.8 3.5 6"/>',
'download':'<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
'sliders':'<path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/>',
'shield':'<path d="M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
'logout':'<path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3M10 8l-4 4 4 4M6 12h10"/>',
'chev':'<path d="M9 6l6 6-6 6"/>',
'search':'<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
'chart':'<path d="M4 20V11M10 20V5M16 20v-6M21 20H3"/>',
'file':'<path d="M6 3h8l5 5v13H6z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
'sparkle':'<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 16l.7 1.8 1.8.7-1.8.7L19 21l-.7-1.8-1.8-.7 1.8-.7z"/>',
'cash':'<rect x="2.5" y="6" width="19" height="12" rx="2.5"/><circle cx="12" cy="12" r="2.5"/><path d="M6 9.5v5M18 9.5v5"/>',
'image':'<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-8 9"/>',
'pin':'<path d="M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
'moon':'<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',
'dollar':'<path d="M12 3v18M16.5 7.5c-.6-1.5-2.3-2.5-4.5-2.5-2.6 0-4.5 1.4-4.5 3.3 0 4.4 9.2 2.5 9.2 7 0 2-2 3.4-4.7 3.4-2.4 0-4.2-1.1-4.8-2.8"/>',
'tag':'<path d="M3 12V4a1 1 0 0 1 1-1h8l9 9-9 9z"/><circle cx="8" cy="8" r="1.5"/>',
'help':'<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6v.6M12 17h.01"/>',
'repeat':'<path d="M4 12a8 8 0 0 1 14-5.3L20 9M20 4v5h-5M20 12a8 8 0 0 1-14 5.3L4 15M4 20v-5h5"/>',
'stop':'<rect x="7" y="7" width="10" height="10" rx="2.5" fill="currentColor"/>',
'wifioff':'<path d="M3 3l18 18M8.5 16.5a5 5 0 0 1 7 0M5 13a10 10 0 0 1 5-2.6M14.5 10.6A10 10 0 0 1 19 13M2 9.5a15 15 0 0 1 4.3-2.7M10.5 5.1A15 15 0 0 1 22 9.5M12 20h.01"/>',
}
def ic(name, size=22, color='currentColor', sw=2.1):
    return (f'<svg width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" stroke="{color}" stroke-width="{sw}" '
            f'stroke-linecap="round" stroke-linejoin="round" style="flex:none;display:block">{ICONS[name]}</svg>')

def whatsapp(size=22, white=False):
    bub = '#fff' if white else '#25D366'; ph = '#25D366' if white else '#fff'
    return (f'<svg width="{size}" height="{size}" viewBox="0 0 24 24" style="flex:none;display:block"><path d="M12 2.4a9.6 9.6 0 0 0-8.3 14.4L2.4 21.6l4.9-1.3A9.6 9.6 0 1 0 12 2.4z" fill="{bub}"/>'
            f'<path d="M9.1 7.3c.3 0 .6 0 .8.5l.8 1.9c.1.3 0 .5-.1.7l-.6.7c.6 1.2 1.6 2.2 2.9 2.9l.7-.7c.2-.2.5-.2.7-.1l1.9.8c.4.2.5.5.4.8-.2 1.3-1.3 2-2.5 2-3.9 0-7.3-3.4-7.3-7.4 0-1.2.9-2.2 2.1-2.4z" fill="{ph}"/></svg>')
def google(size=22):
    return (f'<svg width="{size}" height="{size}" viewBox="0 0 24 24" style="flex:none"><path d="M21.6 12.2c0-.7-.1-1.4-.2-2H12v3.8h5.4a4.6 4.6 0 0 1-2 3v2.5h3.2c1.9-1.7 3-4.3 3-7.3z" fill="#4285F4"/>'
            '<path d="M12 22c2.7 0 5-.9 6.6-2.4l-3.2-2.5c-.9.6-2 1-3.4 1-2.6 0-4.8-1.8-5.6-4.1H3.1v2.6A10 10 0 0 0 12 22z" fill="#34A853"/>'
            '<path d="M6.4 14c-.2-.6-.3-1.3-.3-2s.1-1.4.3-2V7.4H3.1a10 10 0 0 0 0 9.2z" fill="#FBBC05"/>'
            '<path d="M12 5.9c1.5 0 2.8.5 3.8 1.5l2.9-2.9A10 10 0 0 0 3.1 7.4L6.4 10c.8-2.3 3-4.1 5.6-4.1z" fill="#EA4335"/></svg>')
def apple(size=22, color='#111'):
    return (f'<svg width="{size}" height="{size}" viewBox="0 0 24 24" style="flex:none"><path fill="{color}" d="M16.4 12.7c0-2.4 2-3.6 2.1-3.7-1.1-1.7-2.9-1.9-3.5-1.9-1.5-.2-2.9.9-3.7.9-.8 0-1.9-.9-3.200-.8-1.6 0-3.2 1-4 2.500-1.700 3-.4 7.400 1.200 9.800.8 1.200 1.800 2.500 3 2.400 1.200 0 1.700-.8 3.100-.8 1.500 0 1.900.8 3.200.8 1.300 0 2.100-1.200 2.900-2.400.9-1.300 1.300-2.600 1.300-2.700 0 0-2.400-.9-2.400-3.600zM14.200 5.600c.7-.8 1.100-1.900 1-3-.9 0-2.100.6-2.700 1.400-.6.700-1.100 1.800-1 2.900 1 .1 2.100-.5 2.700-1.300z"/></svg>')

def status(light=False, extra=''):
    c = '#fff' if light else '#1F2A3B'
    sig = ''.join(f'<rect x="{i*4.6}" y="{10-3-i*2.2}" width="3.2" height="{3+i*2.2}" rx="1" fill="{c}"/>' for i in range(4))
    return (f'<div class="status{" light" if light else ""}" {extra}><span>9:41</span><div class="r">'
            f'<svg width="18" height="11" viewBox="0 0 18 11">{sig}</svg>'
            f'<svg width="16" height="12" viewBox="0 0 16 12"><path d="M8 11.5 5.6 9a3.4 3.4 0 0 1 4.8 0zM3.4 6.8a6.5 6.5 0 0 1 9.2 0l-1.4 1.4a4.5 4.5 0 0 0-6.4 0zM1 4.4a9.9 9.9 0 0 1 14 0l-1.4 1.4a7.9 7.9 0 0 0-11.2 0z" fill="{c}"/></svg>'
            f'<svg width="27" height="13" viewBox="0 0 27 13"><rect x=".5" y=".5" width="23" height="12" rx="3.8" fill="none" stroke="{c}" opacity=".4"/><rect x="2.5" y="2.5" width="17" height="8" rx="2.2" fill="{c}"/><path d="M25 4.5v4c.8-.3 1.3-1.1 1.3-2s-.5-1.700-1.300-2z" fill="{c}" opacity=".45"/></svg>'
            '</div></div>')

def homeind(light=False):
    return f'<div class="homeind" style="{"background:#fff" if light else ""}"></div>'

def nav(active):
    items = [('home','Inicio'),('bag','Eventos'),None,('clock','Historial'),('user','Perfil')]
    out = '<div class="nav">'
    for it in items:
        if it is None:
            out += f'<div class="fab">{ic("mic",30,"#fff",2.3)}</div>'
        else:
            out += f'<div class="it{" on" if it[1]==active else ""}">{ic(it[0],24)}<span>{it[1]}</span></div>'
    return out + '</div>' + homeind()

PEOPLE = {
 'Laura': dict(bg='#FFD9C7', skin='#E6B08A', hair='#4A2E22', style='long',  shirt='#FF6B4A'),
 'Ana':   dict(bg='#CDEFE0', skin='#C58B66', hair='#1F1A1A', style='bun',   shirt='#2FA774'),
 'Luis':  dict(bg='#D6E8FA', skin='#D8A27A', hair='#2B2220', style='short', shirt='#4C8DE0'),
 'Sofi':  dict(bg='#E6DDFB', skin='#F0C6A4', hair='#8A4B2A', style='curly', shirt='#8F6FE3'),
 'Diego': dict(bg='#FFEFC2', skin='#B47A55', hair='#1E1E1E', style='cap',   shirt='#F2B33D'),
 'Carla': dict(bg='#FFD6E3', skin='#EDC09D', hair='#C9792F', style='bob',   shirt='#E86A92'),
}
def av(name, size=40, ring=None):
    p = PEOPLE[name]; n = uid(); h = p['hair']
    back = ''
    if p['style'] == 'long': back = f'<path d="M12 26 Q11 10 24 10 Q37 10 36 26 L38 46 L10 46Z" fill="{h}"/>'
    if p['style'] == 'bob': back = f'<path d="M12.5 24 Q12 11 24 11 Q36 11 35.5 24 L36.5 32 Q30 34 24 34 Q18 34 11.5 32Z" fill="{h}"/>'
    top = {
     'long': f'<path d="M14 24 Q13 12 24 12 Q35 12 34 24 Q31 16.5 25 16.5 Q19 17 14 24Z" fill="{h}"/>',
     'short': f'<path d="M14.3 22 Q14 11 24 11 Q34 11 33.7 22 Q31.5 15.5 24 15.8 Q16.5 15.5 14.3 22Z" fill="{h}"/>',
     'bun': f'<circle cx="24" cy="9.5" r="5" fill="{h}"/><path d="M14.3 23 Q14 12 24 12 Q34 12 33.7 23 Q31 16 24 16.3 Q17 16 14.3 23Z" fill="{h}"/>',
     'curly': ''.join(f'<circle cx="{x}" cy="{y}" r="4.6" fill="{h}"/>' for x,y in [(14.5,22),(15,16.5),(18.5,12.5),(23.5,11),(28.5,12),(32.5,15.5),(33.5,21)]),
     'cap': f'<path d="M14.6 21 Q14 15 18 15 L30 15 Q34 15 33.4 21Z" fill="{h}"/><path d="M13.6 19 Q14 9.5 24 9.5 Q34 9.5 34.4 19Z" fill="#2D5BA8"/><path d="M29 18 Q38 16.5 41.5 19.5 Q36 21 29 20.5Z" fill="#244C8F"/>',
     'bob': f'<path d="M14 22.5 Q13 12 24 12 Q35 12 34 22.5 Q30 16.5 24 17 Q18 16.5 14 22.5Z" fill="{h}"/>',
    }[p['style']]
    ringcss = f'box-shadow:0 0 0 3px #fff,0 0 0 5.5px {ring};' if ring else ''
    return (f'<svg class="av" width="{size}" height="{size}" viewBox="0 0 48 48" style="{ringcss}"><defs><clipPath id="ac{n}"><circle cx="24" cy="24" r="24"/></clipPath></defs>'
            f'<g clip-path="url(#ac{n})"><rect width="48" height="48" fill="{p["bg"]}"/>{back}'
            f'<path d="M7 52 Q8 37 24 37 Q40 37 41 52Z" fill="{p["shirt"]}"/><rect x="20.5" y="29" width="7" height="9" rx="3" fill="{p["skin"]}"/>'
            f'<ellipse cx="24" cy="23.5" rx="9.5" ry="10.5" fill="{p["skin"]}"/>{top}'
            '<circle cx="20.4" cy="24.5" r="1.25" fill="#2A2A35"/><circle cx="27.6" cy="24.5" r="1.25" fill="#2A2A35"/>'
            '<circle cx="17.8" cy="28" r="1.9" fill="#FF7F6E" opacity=".35"/><circle cx="30.2" cy="28" r="1.9" fill="#FF7F6E" opacity=".35"/>'
            '<path d="M21.2 29 Q24 31.3 26.8 29" stroke="#2A2A35" stroke-width="1.4" fill="none" stroke-linecap="round"/></g></svg>')
def stack(names, size=28):
    return '<div class="stack">' + ''.join(av(n, size) for n in names) + '</div>'

ALL = ['Laura','Ana','Luis','Sofi','Diego','Carla']

def logo(size=48):
    return (f'<svg width="{size}" height="{size}" viewBox="0 0 48 48" style="flex:none"><rect width="48" height="48" rx="15" fill="#FF6B4A"/>'
            '<rect x="11" y="17" width="26" height="19" rx="5" fill="#fff"/><path d="M19 17v-3a3 3 0 0 1 3-3h4a3 3 0 0 1 3 3v3" stroke="#fff" stroke-width="3" fill="none"/>'
            '<circle cx="24" cy="26.5" r="5" fill="#FFC56B"/><path d="M24 23.8v5.4M22.4 25.2h2.6a.9.9 0 0 1 0 1.8h-1.8a.9.9 0 0 0 0 1.8h2.6" stroke="#E9543A" stroke-width="1.1" fill="none" stroke-linecap="round"/></svg>')

# ---------------- Illustrations ----------------
def _svg(body, vb='0 0 360 200', cls='', style='width:100%;height:100%;display:block'):
    return f'<svg viewBox="{vb}" preserveAspectRatio="xMidYMid slice" style="{style}" class="{cls}">{body}</svg>'

def palm(x, y, s=1.0):
    return (f'<g transform="translate({x} {y}) scale({s})"><path d="M-8 84 Q-12 40 6 0" stroke="#A9744F" stroke-width="7" fill="none" stroke-linecap="round"/>'
            '<path d="M-8 84 Q-12 40 6 0" stroke="#8E5E3D" stroke-width="7" fill="none" stroke-dasharray="2 7"/>'
            '<g fill="#3FB37F"><path d="M6 0 Q-16 -20 -44 -8 Q-18 -10 6 0Z"/><path d="M6 0 Q26 -24 54 -14 Q28 -10 6 0Z"/>'
            '<path d="M6 0 Q-2 -30 14 -44 Q10 -20 6 0Z"/></g><g fill="#2E9C6A"><path d="M6 0 Q34 -6 44 18 Q26 4 6 0Z"/>'
            '<path d="M6 0 Q-22 2 -30 24 Q-12 6 6 0Z"/></g><circle cx="3" cy="5" r="4" fill="#7A4E30"/><circle cx="10" cy="4" r="4" fill="#8E5E3D"/></g>')

TALLSKY = ('<g fill="#fff" opacity=".95"><ellipse cx="60" cy="-120" rx="34" ry="11"/><ellipse cx="80" cy="-129" rx="20" ry="12"/><ellipse cx="270" cy="-70" rx="30" ry="10"/><ellipse cx="288" cy="-78" rx="17" ry="11"/></g>'
  '<g transform="translate(250 -150) rotate(-8)"><path d="M0 0 L46 -14 L18 4 Z" fill="#fff"/><path d="M18 4 L22 14 L28 0Z" fill="#E7DED5"/><path d="M-6 6 Q-40 18 -70 6" stroke="#FF6B4A" stroke-width="2" stroke-dasharray="4 5" fill="none" stroke-linecap="round"/></g>'
  '<g stroke="#5D6878" stroke-width="1.8" fill="none" stroke-linecap="round"><path d="M222 -120 q6 -6 12 0 q6 -6 12 0"/><path d="M246 -104 q4 -4 8 0 q4 -4 8 0"/></g>')
def beach(tall=False):
    u = uid()
    b = (f'<defs><linearGradient id="sk{u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFDCCB"/><stop offset="1" stop-color="#FFF3E4"/></linearGradient>'
         f'<linearGradient id="se{u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5FC3D6"/><stop offset="1" stop-color="#A6E3E4"/></linearGradient></defs>'
         + (f'<rect x="-20" y="-200" width="400" height="400" fill="url(#sk{u})"/>' if tall else f'<rect width="360" height="200" fill="url(#sk{u})"/>')
         + (TALLSKY if tall else '') +
         '<circle cx="286" cy="52" r="38" fill="#FFC56B" opacity=".25"/><circle cx="286" cy="52" r="25" fill="#FFC56B"/>'
         '<g fill="#fff" opacity=".9"><ellipse cx="72" cy="42" rx="28" ry="9"/><ellipse cx="88" cy="35" rx="16" ry="10"/><ellipse cx="196" cy="28" rx="22" ry="7"/><ellipse cx="208" cy="23" rx="12" ry="8"/></g>'
         '<path d="M118 114 L176 60 Q183 54 190 60 L252 114Z" fill="#B7C6E6"/><path d="M183 56 Q190 56 192 62 L252 114 L205 114Z" fill="#A5B4D9"/>'
         '<g fill="#fff" opacity=".9"><circle cx="184" cy="49" r="5"/><circle cx="191" cy="42" r="6.5"/><circle cx="200" cy="35" r="5.5"/></g>'
         '<path d="M-4 114 Q40 82 92 104 Q112 110 134 114Z" fill="#9FD8B6"/><path d="M250 114 Q300 92 364 108 V114Z" fill="#B5E2C6"/>'
         f'<rect y="112" width="360" height="60" fill="url(#se{u})"/>'
         '<path d="M246 128 Q252 98 274 95 Q293 93 300 108 Q313 111 316 128Z" fill="#8F899E"/><path d="M274 95 Q293 93 300 108 Q313 111 316 128 L296 128 Q298 108 274 95Z" fill="#7C768C"/>'
         '<ellipse cx="281" cy="129" rx="44" ry="4" fill="#fff" opacity=".75"/>'
         '<g stroke="#fff" stroke-width="2.5" stroke-linecap="round" fill="none" opacity=".85"><path d="M28 128 q8 -5 16 0 t16 0"/><path d="M196 142 q8 -5 16 0 t16 0"/><path d="M112 152 q8 -5 16 0 t16 0"/></g>'
         '<path d="M0 162 Q90 141 190 153 T360 149 V200 H0Z" fill="#F7DDAE"/><path d="M0 162 Q90 141 190 153 T360 149" stroke="#fff" stroke-width="4" fill="none" opacity=".85"/>'
         '<g transform="rotate(-6 196 180)"><rect x="168" y="170" width="56" height="18" rx="4" fill="#FFB4A2"/><rect x="180" y="170" width="7" height="18" fill="#fff" opacity=".7"/><rect x="200" y="170" width="7" height="18" fill="#fff" opacity=".7"/></g>'
         '<g transform="rotate(-14 306 166)"><rect x="297" y="126" width="19" height="66" rx="9.5" fill="#FF6B4A"/><rect x="304.5" y="126" width="4" height="66" fill="#fff" opacity=".75"/></g>'
         + palm(66, 112) +
         '<g stroke="#5D6878" stroke-width="1.6" fill="none" stroke-linecap="round"><path d="M140 54 q5 -5 10 0 q5 -5 10 0"/><path d="M162 66 q4 -4 8 0 q4 -4 8 0"/></g>')
    return _svg(b, vb='0 -170 360 370') if tall else _svg(b)

def volcano():
    u = uid()
    b = (f'<defs><linearGradient id="vs{u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#D3EEF8"/><stop offset="1" stop-color="#EFFAF4"/></linearGradient></defs>'
         f'<rect width="360" height="200" fill="url(#vs{u})"/><circle cx="72" cy="50" r="20" fill="#FFD27A"/>'
         '<g fill="#fff"><ellipse cx="280" cy="40" rx="26" ry="8"/><ellipse cx="294" cy="33" rx="14" ry="9"/></g>'
         '<path d="M-20 150 L56 88 Q68 79 80 88 L160 150Z" fill="#A9C6E6"/>'
         '<path d="M92 156 L166 54 Q180 40 194 54 L272 156Z" fill="#8F86B0"/><path d="M180 45 Q189 45 194 54 L272 156 L206 156Z" fill="#7B729D"/>'
         '<path d="M166 54 Q180 40 194 54 L186 60 Q180 56 174 60Z" fill="#6E668F"/>'
         '<g fill="#fff" opacity=".95"><circle cx="182" cy="38" r="8"/><circle cx="193" cy="28" r="10"/><circle cx="207" cy="20" r="8"/><circle cx="220" cy="17" r="6"/></g>'
         '<path d="M0 158 Q70 128 150 156 T360 146 V200 H0Z" fill="#82CFA2"/>'
         '<ellipse cx="250" cy="172" rx="70" ry="9" fill="#78C6DD"/>'
         '<path d="M0 184 Q100 162 200 182 T360 174 V200H0Z" fill="#5DB888"/>'
         + ''.join(f'<g><rect x="{x-1.5}" y="{y}" width="3" height="10" fill="#7A5A3E"/><circle cx="{x}" cy="{y-2}" r="{r}" fill="#3E9E6B"/></g>' for x,y,r in [(30,158,9),(48,162,7),(318,152,9),(336,156,7),(120,172,8)]))
    return _svg(b)

def food():
    u = uid()
    spots = ''.join(f'<ellipse cx="{x}" cy="{y}" rx="4" ry="2.2" fill="#C98B3E" opacity=".75"/>' for x,y in [(126,108),(140,116),(118,120),(170,98),(184,108),(196,100),(150,132),(162,138),(140,140)])
    b = (f'<rect width="360" height="200" fill="#FFE6D6"/><circle cx="300" cy="40" r="60" fill="#FFD9C4"/><circle cx="40" cy="30" r="34" fill="#FFF1E6"/>'
         '<rect y="150" width="360" height="50" fill="#F2C9A8"/><rect y="150" width="360" height="6" fill="#E9B993"/>'
         '<ellipse cx="160" cy="150" rx="110" ry="38" fill="#E7D9CC"/><ellipse cx="160" cy="142" rx="110" ry="38" fill="#fff"/><ellipse cx="160" cy="142" rx="84" ry="27" fill="#FBF6F1"/>'
         '<ellipse cx="130" cy="122" rx="36" ry="17" fill="#F2C277"/><ellipse cx="182" cy="114" rx="36" ry="17" fill="#EDB868"/><ellipse cx="152" cy="140" rx="38" ry="17" fill="#F5C981"/>' + spots +
         '<ellipse cx="292" cy="142" rx="36" ry="12" fill="#E7D9CC"/><path d="M256 128 Q292 172 328 128Z" fill="#fff"/><ellipse cx="292" cy="128" rx="36" ry="10" fill="#9ED37A"/>'
         + ''.join(f'<path d="M{x} {y} q6 -3 12 0" stroke="{c}" stroke-width="2.4" fill="none" stroke-linecap="round"/>' for x,y,c in [(268,126,'#F58E4E'),(284,124,'#5DB04A'),(296,129,'#F58E4E'),(276,131,'#E6F5C9'),(304,124,'#5DB04A')]) +
         '<path d="M40 150 L46 96 H82 L88 150Z" fill="#fff" opacity=".85"/><path d="M44 118 H84 L88 150 H40Z" fill="#F2E3CF"/><path d="M70 96 L80 70" stroke="#FF6B4A" stroke-width="4" stroke-linecap="round"/>'
         '<g stroke="#fff" stroke-width="3" fill="none" stroke-linecap="round" opacity=".9"><path d="M138 92 q-6 -8 0 -16 t0 -16"/><path d="M162 86 q-6 -8 0 -16 t0 -16"/><path d="M186 90 q-6 -8 0 -16 t0 -16"/></g>')
    return _svg(b)

def road():
    u = uid()
    b = (f'<defs><linearGradient id="rs{u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#DCEBFA"/><stop offset="1" stop-color="#FFF6EA"/></linearGradient></defs>'
         f'<rect width="360" height="200" fill="url(#rs{u})"/><circle cx="296" cy="46" r="20" fill="#FFC56B"/>'
         '<g fill="#fff"><ellipse cx="90" cy="38" rx="24" ry="8"/><ellipse cx="104" cy="31" rx="13" ry="8"/></g>'
         '<path d="M-10 140 Q60 84 140 124 Q200 92 280 118 Q330 100 370 120 V160 H-10Z" fill="#A6DDBA"/>'
         '<path d="M-10 152 Q90 118 190 146 T370 138 V170 H-10Z" fill="#7FCB9E"/>'
         '<rect y="158" width="360" height="30" fill="#5E6A7D"/><rect y="188" width="360" height="12" fill="#7FCB9E"/>'
         + ''.join(f'<rect x="{x}" y="171.5" width="22" height="3.5" rx="1.75" fill="#fff" opacity=".85"/>' for x in range(4, 360, 40)) +
         '<g><rect x="300" y="118" width="4" height="40" fill="#6B7A8E"/><rect x="276" y="104" width="52" height="24" rx="6" fill="#2FA774"/>'
         '<text x="302" y="120" text-anchor="middle" font-family="Poppins" font-weight="700" font-size="10" fill="#fff">El Tunco</text></g>'
         + ''.join(f'<g><rect x="{x-1.5}" y="{y}" width="3" height="12" fill="#7A5A3E"/><circle cx="{x}" cy="{y-3}" r="{r}" fill="#3E9E6B"/></g>' for x,y,r in [(24,142,10),(44,146,7),(236,140,9),(254,144,7)]) +
         '<g transform="translate(96 118)"><rect x="18" y="-8" width="84" height="7" rx="3.5" fill="#FFC56B"/><rect x="24" y="-2" width="4" height="8" fill="#5D6878"/><rect x="88" y="-2" width="4" height="8" fill="#5D6878"/>'
         '<path d="M6 30 Q4 16 18 14 L32 4 Q36 1 42 1 H82 Q90 1 96 8 L106 18 Q118 20 118 30 V38 H6Z" fill="#FF6B4A"/>'
         '<path d="M38 7 H62 V18 H28Z" fill="#CFEAF7"/><path d="M68 7 H82 Q86 7 90 11 L97 18 H68Z" fill="#CFEAF7"/>'
         '<rect x="6" y="24" width="112" height="4" fill="#E9543A"/><circle cx="114" cy="27" r="3" fill="#FFE7A0"/>'
         '<circle cx="32" cy="40" r="11" fill="#2A2F3A"/><circle cx="32" cy="40" r="4.5" fill="#C9D1DB"/><circle cx="92" cy="40" r="11" fill="#2A2F3A"/><circle cx="92" cy="40" r="4.5" fill="#C9D1DB"/></g>')
    return _svg(b)

def flowers():
    u = uid()
    dots = ''
    rnd = random.Random(7)
    for i in range(46):
        x = rnd.uniform(0, 360); y = rnd.uniform(140, 196); c = rnd.choice(['#FF8FA3','#FFC56B','#FF6B4A','#B79CF0','#fff'])
        dots += f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{rnd.uniform(2.2,4):.1f}" fill="{c}"/>'
    b = (f'<rect width="360" height="200" fill="#FDEFE6"/><circle cx="80" cy="54" r="22" fill="#FFC56B"/>'
         '<g fill="#fff"><ellipse cx="250" cy="42" rx="26" ry="8"/><ellipse cx="264" cy="35" rx="14" ry="9"/></g>'
         '<path d="M-10 130 Q80 70 180 118 Q260 80 370 112 V160 H-10Z" fill="#B7DFC1"/>'
         '<path d="M-10 150 Q100 112 200 140 T370 132 V200 H-10Z" fill="#8DD0A3"/>'
         '<g transform="translate(206 92)"><rect x="0" y="22" width="62" height="36" fill="#7DC4E8"/><path d="M-8 24 L31 0 L70 24Z" fill="#E9714A"/><rect x="24" y="36" width="14" height="22" rx="3" fill="#FFC56B"/>'
         '<rect x="6" y="30" width="12" height="10" rx="2" fill="#fff"/><rect x="44" y="30" width="12" height="10" rx="2" fill="#fff"/></g>' + dots)
    return _svg(b)

def wallet_cash(w=150):
    b = ('<ellipse cx="80" cy="146" rx="60" ry="8" fill="#000" opacity=".06"/>'
         '<g transform="rotate(-12 76 52)"><rect x="34" y="28" width="86" height="46" rx="7" fill="#8FD6A6"/><rect x="40" y="34" width="74" height="34" rx="5" fill="none" stroke="#5DB57F" stroke-width="2" stroke-dasharray="3 3"/>'
         '<circle cx="77" cy="51" r="11" fill="#6CC48C"/><text x="77" y="56.5" text-anchor="middle" font-family="Poppins" font-weight="800" font-size="15" fill="#fff">$</text></g>'
         '<g transform="rotate(9 92 46)"><rect x="50" y="22" width="86" height="46" rx="7" fill="#A8E3BC"/><circle cx="93" cy="45" r="11" fill="#8FD6A6"/><text x="93" y="50.5" text-anchor="middle" font-family="Poppins" font-weight="800" font-size="15" fill="#fff">$</text></g>'
         '<rect x="18" y="58" width="124" height="82" rx="20" fill="#FF8A5C"/><path d="M18 78 Q18 58 38 58 H122 Q142 58 142 78 V84 H18Z" fill="#FF6B4A"/>'
         '<rect x="100" y="86" width="50" height="32" rx="12" fill="#E9543A"/><circle cx="116" cy="102" r="6" fill="#FFF3EC"/>'
         '<path d="M30 126 H70" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".45"/>'
         '<circle cx="136" cy="134" r="11" fill="#FFC56B" stroke="#F0A93A" stroke-width="2.5"/><text x="136" y="138.5" text-anchor="middle" font-family="Poppins" font-weight="800" font-size="11" fill="#B86E12">$</text>'
         '<circle cx="20" cy="138" r="8" fill="#FFC56B" stroke="#F0A93A" stroke-width="2"/>'
         '<path d="M140 30 l2.5 6 6 2.5 -6 2.5 -2.5 6 -2.5 -6 -6 -2.5 6 -2.5z" fill="#FFC56B"/>')
    return f'<svg viewBox="0 0 160 160" width="{w}" height="{w}" style="display:block;flex:none">{b}</svg>'

def envelope(w=170):
    b = ('<ellipse cx="90" cy="150" rx="62" ry="7" fill="#000" opacity=".06"/>'
         '<path d="M150 20 Q120 40 130 60 Q140 80 112 92" stroke="#FF6B4A" stroke-width="2.2" stroke-dasharray="5 6" fill="none" stroke-linecap="round"/>'
         '<path d="M134 6 L172 18 L148 28 Z" fill="#FF6B4A"/><path d="M148 28 L152 40 L158 24Z" fill="#E9543A"/>'
         '<rect x="24" y="60" width="132" height="84" rx="14" fill="#fff" stroke="#EADFD4" stroke-width="3"/>'
         '<path d="M26 66 L90 108 L154 66" stroke="#EADFD4" stroke-width="3" fill="#FFF3EC"/>'
         '<rect x="118" y="74" width="26" height="30" rx="4" fill="#9FD8B6"/><path d="M122 98 L128 86 L133 92 L136 88 L141 98Z" fill="#2FA774"/><circle cx="137" cy="81" r="3" fill="#FFC56B"/>'
         '<path d="M90 122 c-6 -6 -14 -2 -12 5 c2 6 12 11 12 11 s10 -5 12 -11 c2 -7 -6 -11 -12 -5z" fill="#FF8FA3"/>')
    return f'<svg viewBox="0 0 180 160" width="{w}" height="{w*160/180:.0f}" style="display:block;flex:none">{b}</svg>'

def coins(w=110):
    b = ('<ellipse cx="60" cy="98" rx="34" ry="10" fill="#000" opacity=".08"/>'
         + ''.join(f'<ellipse cx="60" cy="{y}" rx="30" ry="9" fill="#F0A93A"/><ellipse cx="60" cy="{y-4}" rx="30" ry="9" fill="#FFC56B"/>' for y in (96, 86, 76, 66)) +
         '<text x="60" y="67" text-anchor="middle" font-family="Poppins" font-weight="800" font-size="11" fill="#B86E12">$</text>'
         '<rect x="70" y="20" width="44" height="26" rx="5" fill="#8FD6A6" transform="rotate(18 92 33)"/><circle cx="92" cy="33" r="6" fill="#6CC48C" transform="rotate(18 92 33)"/>')
    return f'<svg viewBox="0 0 120 110" width="{w}" height="{w*110/120:.0f}" style="display:block;flex:none">{b}</svg>'

def qr(size=150, seed=3):
    n = 25; rnd = random.Random(seed); cell = 1
    out = []
    def finder(x, y):
        return (f'<rect x="{x}" y="{y}" width="7" height="7" rx="1.6" fill="#1F2A3B"/><rect x="{x+1}" y="{y+1}" width="5" height="5" rx="1" fill="#fff"/>'
                f'<rect x="{x+2}" y="{y+2}" width="3" height="3" rx=".8" fill="#1F2A3B"/>')
    for r in range(n):
        for c in range(n):
            if (r < 8 and c < 8) or (r < 8 and c > n-9) or (r > n-9 and c < 8): continue
            if 10 <= r <= 14 and 10 <= c <= 14: continue
            if rnd.random() < .5: out.append(f'<rect x="{c}" y="{r}" width="1.02" height="1.02" fill="#1F2A3B"/>')
    center = '<rect x="10" y="10" width="5" height="5" rx="1.4" fill="#FF6B4A"/><path d="M11.4 12.6 h2.2" stroke="#fff" stroke-width=".7"/>'
    return (f'<svg viewBox="-1 -1 27 27" width="{size}" height="{size}" style="display:block" shape-rendering="crispEdges">'
            + ''.join(out) + finder(0,0) + finder(n-7,0) + finder(0,n-7) + center + '</svg>')

def page(title, body, bg='var(--cream)'):
    return (f'<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=390">'
            f'<title>{title}</title><link rel="stylesheet" href="../styles.css"></head><body style="background:{bg}">{body}</body></html>')
