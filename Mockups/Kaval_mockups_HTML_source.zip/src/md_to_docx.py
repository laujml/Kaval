import re, sys
from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
md = open(sys.argv[1], encoding='utf-8').read().splitlines()
doc = Document()
for s in doc.sections:
    s.left_margin = s.right_margin = Cm(2.2); s.top_margin = s.bottom_margin = Cm(2)
st = doc.styles['Normal']; st.font.name = 'Calibri'; st.font.size = Pt(11)
CORAL = RGBColor(0xE9,0x54,0x3A); INK = RGBColor(0x1F,0x2A,0x3B)
def runs(p, text):
    for part in re.split(r'(\*\*[^*]+\*\*|`[^`]+`|\*[^*]+\*)', text):
        if not part: continue
        if part.startswith('**'): r = p.add_run(part[2:-2]); r.bold = True
        elif part.startswith('`'): r = p.add_run(part[1:-1]); r.font.name = 'Consolas'
        elif part.startswith('*') and len(part) > 2: r = p.add_run(part[1:-1]); r.italic = True
        else: p.add_run(part)
def shade(cell, color):
    tcPr = cell._tc.get_or_add_tcPr(); shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear'); shd.set(qn('w:color'), 'auto'); shd.set(qn('w:fill'), color); tcPr.append(shd)
i = 0; first_h2 = True
while i < len(md):
    line = md[i]
    if line.startswith('```'):
        buf = []; i += 1
        while not md[i].startswith('```'): buf.append(md[i]); i += 1
        t = doc.add_table(rows=1, cols=1); t.autofit = True
        c = t.rows[0].cells[0]; shade(c, 'FFF3EC')
        p = c.paragraphs[0]; r = p.add_run('\n'.join(buf)); r.font.size = Pt(10.5)
        doc.add_paragraph()
    elif line.startswith('# '):
        h = doc.add_heading(line[2:], 0)
        for r in h.runs: r.font.color.rgb = INK; r.font.size = Pt(22)
        if len(sys.argv) > 3:
            doc.add_picture(sys.argv[3], width=Cm(16.5))
    elif line.startswith('## '):
        h = doc.add_heading(line[3:], 1)
        for r in h.runs: r.font.color.rgb = CORAL
    elif line.strip() == '---':
        pass
    elif line.strip():
        p = doc.add_paragraph(); runs(p, line)
        if line.strip() in ('**ES**', '**EN**'): p.paragraph_format.space_after = Pt(2)
    i += 1
doc.save(sys.argv[2]); print('saved', sys.argv[2])
