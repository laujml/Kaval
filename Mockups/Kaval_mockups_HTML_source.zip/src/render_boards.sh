#!/bin/bash
cd "$(dirname "$0")"
python3 boards.py
google-chrome --headless=new --no-sandbox --disable-gpu --hide-scrollbars --force-device-scale-factor=1.5 --window-size=2840,2070 --virtual-time-budget=3000 --screenshot=../Kaval_overview_board.png "file://$PWD/board.html" >/dev/null 2>&1
google-chrome --headless=new --no-sandbox --disable-gpu --hide-scrollbars --force-device-scale-factor=2 --window-size=1700,1000 --virtual-time-budget=3000 --screenshot=../Kaval_hero.png "file://$PWD/hero.html" >/dev/null 2>&1
