from lib import *

S = {}  # filename -> html

# ---------- 01 Onboarding ----------
def s01():
    bubble = lambda emo, t, amt, who, style: (f'<div class="card row" style="position:absolute;{style};padding:10px 14px 10px 10px;gap:10px;border-radius:20px;box-shadow:0 12px 28px rgba(31,42,59,.12)">'
        f'<div class="etile" style="width:38px;height:38px;border-radius:13px;font-size:19px;background:var(--peach)">{emo}</div>'
        f'<div><div style="font-weight:800;font-size:13.5px">{t}</div><div class="tiny">{who}</div></div><div class="pop" style="font-weight:700;font-size:15px;margin-left:4px">{amt}</div></div>')
    b = status() + '<div class="px row between" style="margin-top:4px"><div class="row" style="gap:8px">' + logo(34) + '<span class="pop" style="font-weight:700;font-size:20px;letter-spacing:-.3px">kaval</span></div><span class="small" style="font-weight:800">Saltar</span></div>'
    b += ('<div style="position:relative;margin:18px 20px 0;height:390px;border-radius:36px;overflow:hidden;background:var(--mint)">' + beach(tall=True) + '</div>')
    b += bubble('⛽','Gasolina','$24.00','Pagó Laura · 6 personas','top:262px;right:34px')
    b += bubble('🫓','Pupusas','$18.50','Efectivo · 5 personas','top:138px;right:34px')
    b += f'<div class="card row" style="position:absolute;top:202px;left:40px;padding:8px 12px;gap:8px;border-radius:18px;box-shadow:0 12px 28px rgba(31,42,59,.12)"><div style="width:30px;height:30px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center">{ic("mic",17,"#fff")}</div><span style="font-weight:800;font-size:13px">“pagué 24 de gasolina”</span></div>'
    b += ('<div class="px" style="margin-top:30px"><div class="h1" style="font-size:30px">Viajen juntos,<br>cuentas <span style="color:var(--accent)">claras</span> ✨</div>'
          '<div class="sub" style="margin-top:12px;font-size:15.5px">Dicta tus gastos, mira quién le debe a quién y comparte el resumen en segundos.</div>'
          '<div class="row" style="gap:6px;margin-top:20px"><div style="width:26px;height:8px;border-radius:4px;background:var(--accent)"></div><div style="width:8px;height:8px;border-radius:4px;background:#E7DED5"></div><div style="width:8px;height:8px;border-radius:4px;background:#E7DED5"></div></div></div>')
    b += ('<div class="px" style="position:absolute;bottom:34px;left:0;right:0"><div class="btn">Comenzar ' + ic('arrow',20,'#fff') + '</div>'
          '<div style="text-align:center;margin-top:16px" class="small">¿Ya tienes cuenta? <span class="link">Inicia sesión</span></div></div>' + homeind())
    return b

# ---------- 02 Login ----------
def s02():
    b = status()
    b += ('<div style="position:absolute;top:0;left:0;right:0;height:250px;overflow:hidden;border-radius:0 0 40px 40px">' + road() + '</div>')
    b += f'<div class="px" style="position:relative;margin-top:150px"><div class="card" style="padding:24px 20px 22px;border-radius:30px">'
    b += ('<div class="row" style="gap:10px">' + logo(40) + '<div><div class="h2" style="font-size:21px">¡Hola de nuevo! 👋</div><div class="small">Tus viajes y cuentas, sincronizados.</div></div></div>'
          '<div class="seg" style="margin-top:18px"><div class="on">Iniciar sesión</div><div>Crear cuenta</div></div>'
          f'<div class="label" style="margin-top:18px">Correo electrónico</div><div class="field focus">{ic("mail",20,"var(--ink3)")}<span>laura.angel@email.com</span></div>'
          f'<div class="label" style="margin-top:14px">Contraseña</div><div class="field">{ic("lock",20,"var(--ink3)")}<span style="letter-spacing:3px;flex:1">••••••••••</span>{ic("eye",20,"var(--ink3)")}</div>'
          '<div style="text-align:right;margin-top:10px"><span class="link" style="font-size:13px">¿Olvidaste tu contraseña?</span></div>'
          '<div class="btn" style="margin-top:14px">Iniciar sesión</div></div></div>')
    b += ('<div class="px"><div class="row" style="gap:12px;margin:20px 0 14px"><div class="divider" style="flex:1"></div><span class="tiny" style="font-size:12.5px">o continúa con</span><div class="divider" style="flex:1"></div></div>'
          f'<div class="row" style="gap:12px"><div class="btn ghost" style="flex:1;font-size:15px">{google(20)} Google</div><div class="btn ghost" style="flex:1;font-size:15px">{apple(21)} Apple</div></div>'
          f'<div class="row" style="justify-content:center;gap:6px;margin-top:18px" class="small"><span class="small">¿Sin internet?</span><span class="link" style="font-size:13px">Usar perfil local</span>{ic("chev",14,"var(--accent-d)",2.6)}</div></div>')
    return b + homeind()

# ---------- 03 Inicio ----------
def event_card(ill, title, place, members, total, state, stcls, w=268):
    return (f'<div class="card" style="width:{w}px;flex:none;padding:8px 8px 14px;border-radius:28px">'
            f'<div style="height:128px;border-radius:22px;overflow:hidden;position:relative">{ill}'
            f'<div class="tag" style="position:absolute;top:10px;left:10px;background:rgba(255,255,255,.92);color:var(--ink)">{ic("cloudcheck",14,"var(--green)",2.4)} Sincronizado</div></div>'
            f'<div style="padding:12px 8px 0"><div class="h3">{title}</div><div class="row small" style="gap:4px;margin-top:2px">{ic("pin",14,"var(--ink3)")} {place}</div>'
            f'<div class="row between" style="margin-top:12px">{stack(members,28)}<div style="text-align:right"><div class="tiny">Total</div><div class="pop" style="font-weight:700;font-size:16px">{total}</div></div></div>'
            f'<div class="tag {stcls}" style="margin-top:10px">{state}</div></div></div>')
def s03():
    b = status()
    b += (f'<div class="px row between" style="margin-top:6px"><div class="row" style="gap:12px">{av("Laura",50)}<div>'
          '<div class="pop" style="font-weight:700;font-size:22px;letter-spacing:-.4px">Hola, Laura 👋</div><div class="small">¿A dónde vamos hoy?</div></div></div>'
          f'<div class="iconbtn" style="position:relative">{ic("bell",22)}<span style="position:absolute;top:11px;right:12px;width:8px;height:8px;border-radius:50%;background:var(--accent);box-shadow:0 0 0 2px #fff"></span></div></div>')
    b += ('<div class="px" style="margin-top:18px"><div style="position:relative;overflow:hidden;border-radius:28px;padding:20px 22px;background:linear-gradient(135deg,#FF8A5C 0%,#FF6B4A 55%,#F55A43 100%);color:#fff;box-shadow:0 14px 30px rgba(255,107,74,.35)">'
          '<div style="position:absolute;right:-30px;top:-40px;width:150px;height:150px;border-radius:50%;background:rgba(255,255,255,.12)"></div>'
          f'<div style="position:absolute;right:8px;top:16px">{coins(96)}</div>'
          '<div style="font-weight:800;font-size:13.5px;opacity:.9">Balance general</div><div class="pop" style="font-weight:700;font-size:36px;letter-spacing:-1px;margin-top:2px">+$4.65</div>'
          '<div class="row" style="gap:8px;margin-top:12px"><div class="tag" style="background:rgba(255,255,255,.22);color:#fff;height:28px;font-size:12.5px">↓ Te deben $15.25</div><div class="tag" style="background:rgba(255,255,255,.22);color:#fff;height:28px;font-size:12.5px">↑ Debes $10.60</div></div></div></div>')
    b += ('<div class="row" style="gap:8px;margin-top:20px;padding-left:20px;overflow:hidden;white-space:nowrap"><div class="chip on">Todos</div><div class="chip">🏖️ Playa</div><div class="chip">🌋 Volcán</div><div class="chip">🍽️ Comidas</div><div class="chip">🚗 Road trip</div></div>')
    b += '<div class="px sechead" style="margin-top:20px"><div class="h3" style="font-size:18px">Eventos activos</div><span class="link">Ver todos</span></div>'
    b += ('<div class="row" style="gap:14px;padding-left:20px;align-items:flex-start">'
          + event_card(beach(), 'Playa El Tunco 🌊', 'La Libertad · 2–4 oct', ALL, '$202.00', 'Debes $10.60', 'r')
          + event_card(flowers(), 'Ruta de las Flores 🌸', 'Ahuachapán · 9–10 oct', ['Laura','Ana','Carla','Diego'], '$86.00', 'Te deben $15.25', 'g') + '</div>')
    b += f'<div class="px" style="margin-top:14px"><div class="row" style="gap:8px;height:40px;border-radius:14px;background:var(--mint);padding:0 14px">{ic("mic",17,"var(--green)")}<span style="font-size:13px;font-weight:700;color:var(--ink2)">Tip: solo di <b style="color:var(--ink)">“pagué 24 de gasolina”</b> 🎙️</span></div></div>'
    return b + nav('Inicio')

# ---------- 04 Crear evento ----------
def s04():
    b = status()
    b += f'<div class="px row between" style="margin-top:6px"><div class="iconbtn">{ic("back",22)}</div><div class="h2" style="font-size:18px">Nuevo evento</div><div style="width:44px"></div></div>'
    b += f'<div class="px" style="margin-top:16px"><div class="label">Nombre del evento</div><div class="field focus" style="font-size:17px"><span>Playa El Tunco 🌊</span><span style="width:2px;height:22px;background:var(--accent);margin-left:-8px"></span></div>'
    thumbs = [(beach(),'Playa',True),(volcano(),'Volcán',False),(food(),'Comida',False),(road(),'Road trip',False)]
    b += '<div class="label" style="margin-top:18px">Portada</div><div class="row" style="gap:10px">'
    for ill, name, on in thumbs:
        ring = 'box-shadow:0 0 0 3px #fff,0 0 0 5.5px var(--accent);' if on else ''
        chk = f'<div style="position:absolute;top:6px;right:6px;width:22px;height:22px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center">{ic("check",14,"#fff",3)}</div>' if on else ''
        b += f'<div style="flex:1"><div style="height:68px;border-radius:18px;overflow:hidden;position:relative;{ring}">{ill}{chk}</div><div class="tiny" style="text-align:center;margin-top:7px;color:{"var(--ink)" if on else "var(--ink3)"}">{name}</div></div>'
    b += '</div>'
    b += (f'<div class="row" style="gap:12px;margin-top:16px"><div style="flex:1"><div class="label">Inicio</div><div class="field" style="height:52px;font-size:15px">{ic("calendar",19,"var(--accent)")} 2 oct 2026</div></div>'
          f'<div style="flex:1"><div class="label">Fin</div><div class="field" style="height:52px;font-size:15px">{ic("calendar",19,"var(--accent)")} 4 oct 2026</div></div></div>'
          f'<div class="row between" style="margin-top:14px;background:var(--mint);border-radius:18px;padding:12px 16px"><div class="row" style="gap:10px">{ic("dollar",20,"var(--green)")}<span style="font-weight:800;font-size:14.5px">Moneda: USD ($)</span></div><span class="tag g">Fija</span></div>')
    b += '<div class="sechead" style="margin-top:20px;margin-bottom:10px"><div class="h3">Integrantes <span style="color:var(--ink3)">(6)</span></div><span class="link row" style="gap:4px">' + ic('link',16,'var(--accent-d)') + 'Invitar con código</span></div>'
    b += '<div style="display:flex;flex-wrap:wrap;gap:8px">'
    for n in ALL:
        extra = ' <span class="tag a" style="height:20px;padding:0 7px;font-size:11px">Tú</span>' if n=='Laura' else ('')
        b += f'<div class="chip" style="padding:0 12px 0 4px;height:40px;gap:7px;color:var(--ink)">{av(n,32)}{n}{extra}{"" if n=="Laura" else ic("close",14,"var(--ink3)",2.4)}</div>'
    b += '</div>'
    b += f'<div class="field" style="margin-top:12px;height:52px;font-size:15px;color:var(--ink3)">{ic("user",19,"var(--ink3)")}<span style="flex:1">Agregar por nombre…</span><div style="width:34px;height:34px;border-radius:12px;background:var(--accent);display:flex;align-items:center;justify-content:center;margin-right:-6px">{ic("plus",18,"#fff",2.6)}</div></div></div>'
    b += f'<div class="px" style="position:absolute;bottom:34px;left:0;right:0"><div class="btn">{ic("check",20,"#fff",2.6)} Crear evento</div></div>' + homeind()
    return b

# ---------- 05 Detalle ----------
EXP = [
 ('⛽','Gasolina','Pagó Laura · 6 personas','$24.00','var(--peach)','🎙️ Dictado','a'),
 ('🫓','Pupusas','Efectivo del grupo · 5 personas','$18.50','var(--sun)','💵 Efectivo','g'),
 ('🥥','Cocos y agua','Efectivo del grupo · 5 personas','$9.50','var(--mint)','💵 Efectivo','g'),
 ('🎟️','Entradas beach club','Pagó Luis · 6 personas','$30.00','var(--lav)',None,''),
 ('🏠','Hospedaje','Pagó Sofi · 6 personas','$120.00','var(--sky)',None,''),
]
BAL = [('Laura','−$10.60','neg'),('Ana','−$13.60','neg'),('Luis','+$2.40','pos'),('Sofi','+$85.40','pos'),('Diego','−$34.60','neg'),('Carla','−$29.00','neg')]
def exp_row(e):
    emo,t,s,amt,bg,tag,tc = e
    tg = f'<span class="tag {tc}" style="height:20px;font-size:10.5px;padding:0 7px">{tag}</span>' if tag else ''
    return (f'<div class="card row" style="padding:10px 14px 10px 10px;gap:12px;border-radius:22px;margin-bottom:10px"><div class="etile" style="background:{bg}">{emo}</div>'
            f'<div style="flex:1;min-width:0"><div class="row" style="gap:6px"><span style="font-weight:800;font-size:15px">{t}</span>{tg}</div><div class="tiny" style="margin-top:2px;font-size:12px">{s}</div></div>'
            f'<div class="pop" style="font-weight:700;font-size:15.5px">{amt}</div></div>')
def s05():
    b = f'<div style="position:absolute;top:0;left:0;right:0;height:214px;overflow:hidden">{beach()}</div>' + status()
    b += f'<div class="px row between" style="position:relative;margin-top:6px"><div class="iconbtn" style="background:rgba(255,255,255,.9)">{ic("back",22)}</div><div class="row" style="gap:10px"><div class="iconbtn" style="background:rgba(255,255,255,.9)">{ic("share",20)}</div><div class="iconbtn" style="background:rgba(255,255,255,.9)">{ic("users",20)}</div></div></div>'
    b += ('<div class="px" style="position:relative;margin-top:56px"><div class="card" style="padding:18px 18px 16px;border-radius:28px;box-shadow:0 12px 34px rgba(31,42,59,.1)">'
          f'<div class="row between"><div class="h2" style="font-size:21px">Playa El Tunco 🌊</div><span class="tag g">{ic("cloudcheck",14,"var(--green)",2.4)} Sincronizado</span></div>'
          f'<div class="row small" style="gap:4px;margin-top:2px">{ic("calendar",14,"var(--ink3)")} 2–4 oct · 6 integrantes · USD</div>'
          '<div class="row" style="margin-top:14px;background:var(--cream);border-radius:18px;padding:12px 4px">'
          '<div style="flex:1;text-align:center"><div class="tiny">Total</div><div class="pop" style="font-weight:700;font-size:17px">$202.00</div></div><div style="width:1px;height:32px;background:var(--line)"></div>'
          '<div style="flex:1;text-align:center"><div class="tiny">Tu parte</div><div class="pop" style="font-weight:700;font-size:17px">$34.60</div></div><div style="width:1px;height:32px;background:var(--line)"></div>'
          '<div style="flex:1;text-align:center"><div class="tiny">Debes</div><div class="pop neg" style="font-weight:700;font-size:17px">$10.60</div></div></div></div></div>')
    b += '<div class="px sechead" style="margin-top:18px;margin-bottom:10px"><div class="h3">Saldos por persona</div><span class="link">Liquidar →</span></div>'
    b += '<div class="row" style="gap:8px;padding-left:20px">'
    for n, amt, c in BAL:
        hl = 'box-shadow:inset 0 0 0 2px var(--accent);' if n=='Laura' else ''
        b += f'<div class="card" style="width:74px;flex:none;padding:10px 4px;text-align:center;border-radius:20px;{hl}"><div style="display:flex;justify-content:center">{av(n,34)}</div><div style="font-weight:800;font-size:12.5px;margin-top:4px">{"Tú" if n=="Laura" else n}</div><div class="pop {c}" style="font-weight:700;font-size:12.5px">{amt}</div></div>'
    b += '</div>'
    b += '<div class="px sechead" style="margin-top:18px;margin-bottom:10px"><div class="h3">Gastos <span style="color:var(--ink3)">(5)</span></div><span class="tag n">Más recientes</span></div><div class="px">'
    b += ''.join(exp_row(e) for e in EXP) + '</div>'
    b += ('<div style="position:absolute;left:0;right:0;bottom:90px;height:60px;background:linear-gradient(180deg,rgba(255,248,240,0),#FFF8F0);z-index:19"></div><div style="position:absolute;left:0;right:0;bottom:0;height:104px;background:#fff;border-radius:30px 30px 0 0;box-shadow:0 -8px 30px rgba(31,42,59,.08);display:flex;align-items:flex-start;gap:12px;padding:14px 20px 0;z-index:20">'
          f'<div class="btn ghost" style="flex:1;height:54px;font-size:15px">{ic("repeat",19)} Liquidar</div>'
          f'<div style="width:62px;height:62px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center;margin-top:-22px;box-shadow:0 12px 24px rgba(255,107,74,.42),0 0 0 6px #fff;flex:none">{ic("mic",28,"#fff",2.3)}</div>'
          f'<div class="btn" style="flex:1;height:54px;font-size:15px">{ic("plus",19,"#fff",2.6)} Gasto</div></div>' + homeind())
    return b

# ---------- 06 Gasto manual ----------
def step(n): return f'<span style="width:22px;height:22px;border-radius:50%;background:var(--accent);color:#fff;font-size:12px;font-weight:900;display:inline-flex;align-items:center;justify-content:center;flex:none">{n}</span>'
def s06():
    b = status()
    b += f'<div class="px row between" style="margin-top:6px"><div class="iconbtn">{ic("close",22)}</div><div style="text-align:center"><div class="h2" style="font-size:18px">Nuevo gasto</div><div class="tiny">Playa El Tunco 🌊</div></div><div class="iconbtn" style="color:var(--accent)">{ic("mic",21)}</div></div>'
    b += (f'<div class="px" style="margin-top:14px"><div class="card" style="padding:12px 18px 14px;border-radius:28px;text-align:center;background:var(--peach);box-shadow:none">'
          f'<div class="row" style="justify-content:center;gap:6px">{step(1)}<span class="small" style="font-weight:800">Monto</span></div>'
          '<div class="pop" style="font-weight:700;font-size:44px;letter-spacing:-1.5px;margin-top:0"><span style="color:var(--ink3);font-size:32px;vertical-align:8px;margin-right:4px">$</span>36.00</div>'
          '<div class="row" style="justify-content:center;gap:8px;margin-top:6px"><div class="field" style="height:42px;border-radius:14px;font-size:14.5px;padding:0 14px">Cena de mariscos 🦐</div></div></div>')
    b += '<div class="row" style="gap:8px;margin-top:14px;overflow:hidden;white-space:nowrap"><div class="chip accs">🍽️ Comida</div><div class="chip">⛽ Transporte</div><div class="chip">🏠 Hospedaje</div><div class="chip">🎉 Diversión</div></div>'
    b += f'<div class="row" style="gap:8px;margin-top:20px">{step(2)}<div class="h3">¿Quién pagó?</div></div><div class="row" style="gap:14px;margin-top:12px">'
    for n in ALL:
        on = n=='Diego'
        b += f'<div style="text-align:center;width:44px">{av(n,44, "var(--accent)" if on else None)}<div style="font-size:12px;font-weight:{900 if on else 700};margin-top:6px;color:{"var(--accent-d)" if on else "var(--ink2)"}">{"Tú" if n=="Laura" else n}</div></div>'
    b += '</div>'
    b += f'<div class="row between" style="margin-top:20px"><div class="row" style="gap:8px">{step(3)}<div class="h3">¿Entre quiénes?</div></div><span class="chip acc" style="height:30px;font-size:12.5px;padding:0 12px">{ic("check",14,"#fff",3)} Todos</span></div>'
    b += '<div class="card" style="margin-top:12px;padding:6px 16px;border-radius:22px">'
    for i, n in enumerate(ALL[:2]):
        b += (f'<div class="row" style="gap:12px;padding:8px 0;{"border-top:1px solid var(--line)" if i else ""}">{av(n,34)}<span style="flex:1;font-weight:800;font-size:15px">{"Laura (tú)" if n=="Laura" else n}</span>'
              f'<span class="small" style="font-weight:800">$6.00</span><div style="width:24px;height:24px;border-radius:8px;background:var(--accent);display:flex;align-items:center;justify-content:center">{ic("check",15,"#fff",3)}</div></div>')
    b += f'<div class="row" style="gap:10px;padding:8px 0;border-top:1px solid var(--line)">{stack(["Luis","Sofi","Diego","Carla"],26)}<span class="small" style="flex:1;font-weight:800">+4 más · $6.00 c/u</span><span class="link" style="font-size:13px">Ajustar</span></div></div>'
    b += f'<div class="row" style="gap:8px;margin-top:12px"><div class="seg" style="flex:1"><div class="on">💳 Tarjeta</div><div>💵 Efectivo del grupo</div></div></div></div>'
    b += (f'<div class="px" style="position:absolute;bottom:34px;left:0;right:0"><div class="btn">{step(4).replace("var(--accent)","#fff").replace("color:#fff","color:var(--accent)")} Guardar gasto · $36.00</div></div>' + homeind())
    return b

# ---------- 07 Dictar ----------
def s07():
    b = status()
    b += f'<div class="px row between" style="margin-top:6px;position:relative;z-index:3"><div class="iconbtn">{ic("close",22)}</div><div class="chip" style="height:36px;color:var(--ink)">🌊 Playa El Tunco</div><div class="iconbtn">{ic("help",21)}</div></div>'
    b += ('<div style="text-align:center;margin-top:34px"><div class="row" style="justify-content:center;gap:8px"><span style="width:10px;height:10px;border-radius:50%;background:var(--red);box-shadow:0 0 0 4px rgba(229,72,77,.18)"></span>'
          '<span style="font-weight:900;font-size:14px;color:var(--red);letter-spacing:.5px">ESCUCHANDO · 0:04</span></div>'
          '<div class="pop" style="font-weight:600;font-size:27px;line-height:1.3;letter-spacing:-.4px;margin:22px 30px 0">“Pagué <span style="color:var(--accent)">24 dólares</span> de <span style="color:var(--accent)">gasolina</span> por <span style="color:var(--accent)">todos</span><span style="display:inline-block;width:3px;height:28px;background:var(--accent);vertical-align:-4px;margin-left:3px;border-radius:2px"></span>”</div>'
          '<div class="small" style="margin-top:10px">Transcribiendo en tu dispositivo…</div></div>')
    bars = ''
    for i in range(38):
        h = 8 + abs(math.sin(i*0.55)*34 + math.sin(i*1.7)*14) * (1 - abs(i-18.5)/24)
        op = 1 if 6 <= i <= 31 else .35
        bars += f'<div style="width:4px;height:{h:.0f}px;border-radius:2px;background:var(--accent);opacity:{op}"></div>'
    b += f'<div class="row" style="justify-content:center;gap:4px;height:80px;margin-top:22px">{bars}</div>'
    b += ('<div style="position:relative;height:250px;display:flex;align-items:center;justify-content:center;margin-top:6px">'
          '<div style="position:absolute;width:236px;height:236px;border-radius:50%;background:rgba(255,107,74,.08)"></div>'
          '<div style="position:absolute;width:182px;height:182px;border-radius:50%;background:rgba(255,107,74,.13)"></div>'
          '<div style="position:absolute;width:136px;height:136px;border-radius:50%;background:rgba(255,107,74,.2)"></div>'
          f'<div style="position:relative;width:98px;height:98px;border-radius:50%;background:linear-gradient(145deg,#FF8A5C,#F55A43);display:flex;align-items:center;justify-content:center;box-shadow:0 16px 30px rgba(255,107,74,.5)">{ic("mic",44,"#fff",2.2)}</div></div>')
    b += (f'<div class="row" style="justify-content:space-between;padding:0 54px;margin-top:-6px"><div style="text-align:center"><div class="iconbtn" style="width:54px;height:54px;border-radius:50%">{ic("close",22,"var(--ink2)")}</div><div class="tiny" style="margin-top:6px">Cancelar</div></div>'
          f'<div style="text-align:center"><div class="iconbtn" style="width:54px;height:54px;border-radius:50%;background:var(--ink);color:#fff">{ic("stop",22,"#fff")}</div><div class="tiny" style="margin-top:6px">Listo</div></div>'
          f'<div style="text-align:center"><div class="iconbtn" style="width:54px;height:54px;border-radius:50%">{ic("keyboard",22,"var(--ink2)")}</div><div class="tiny" style="margin-top:6px">Escribir</div></div></div>')
    b += '<div class="px" style="margin-top:18px"><div style="text-align:center;font-size:13px;font-weight:700;color:var(--ink2);line-height:1.4">💡 Prueba: <i>“Ana pagó 18.50 de pupusas para todos menos Carla”</i></div></div>'
    b += f'<div class="px" style="position:absolute;bottom:30px;left:0;right:0"><div class="row" style="justify-content:center;gap:6px;background:rgba(255,255,255,.7);border-radius:16px;padding:10px">{ic("lock",15,"var(--green)",2.4)}<span class="small" style="font-size:12.5px">Solo guardamos el texto, nunca el audio</span></div></div>'
    return b + homeind()

# ---------- 08 Confirmar dictado ----------
def s08():
    b = status()
    b += f'<div class="row" style="margin:4px 20px 0;gap:10px;background:#FFF1CC;border-radius:16px;padding:10px 14px">{ic("cloudoff",19,"#B7791F")}<span style="font-weight:800;font-size:13px;color:#8A5A12;flex:1">Sin conexión · se sincronizará al volver</span></div>'
    b += f'<div class="px row between" style="margin-top:10px"><div class="iconbtn">{ic("back",22)}</div><div class="h2" style="font-size:18px">Confirma tu gasto</div><div style="width:44px"></div></div>'
    b += (f'<div class="px" style="margin-top:12px"><div class="row" style="gap:10px;align-items:flex-start"><div style="width:36px;height:36px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center;flex:none">{ic("mic",18,"#fff")}</div>'
          '<div style="background:#fff;border-radius:6px 20px 20px 20px;padding:10px 14px;box-shadow:0 6px 18px rgba(31,42,59,.06)"><div style="font-weight:700;font-size:14.5px;font-style:italic">“Pagué 24 dólares de gasolina por todos”</div><div class="tiny" style="margin-top:4px">Laura · hace un momento</div></div></div></div>')
    rows = [
      ('dollar','Monto','<span class="pop" style="font-size:22px;font-weight:700">$24.00</span>'),
      ('tag','Concepto','<span style="font-weight:800">Gasolina</span> <span class="tag a" style="margin-left:4px">⛽ Transporte</span>'),
      ('user','Pagó',f'<span class="row" style="gap:8px;justify-content:flex-end">{av("Laura",28)}<b>Laura (tú)</b></span>'),
      ('users','Participantes',f'<span class="row" style="gap:8px;justify-content:flex-end">{stack(ALL,22)}<b style="white-space:nowrap">Todos (6)</b></span>'),
      ('wallet','Método','<b>💳 Tarjeta</b>'),
    ]
    b += ('<div class="px" style="margin-top:14px"><div class="card" style="padding:16px 18px 14px;border-radius:28px;box-shadow:0 14px 36px rgba(31,42,59,.09)">'
          f'<div class="row between" style="margin-bottom:6px"><div class="row" style="gap:6px">{ic("sparkle",19,"var(--accent)")}<span class="h3">Detectamos esto</span></div><span class="tag g">Alta confianza</span></div>')
    for i,(icn,lab,val) in enumerate(rows):
        b += (f'<div class="row" style="gap:12px;padding:8px 0;{"border-top:1px solid var(--line)" if i else ""}"><div style="width:34px;height:34px;border-radius:12px;background:var(--cream);display:flex;align-items:center;justify-content:center;flex:none">{ic(icn,18,"var(--ink2)")}</div>'
              f'<span class="small" style="flex:1">{lab}</span><div style="font-size:15px;text-align:right">{val}</div>{ic("edit",16,"var(--ink3)")}</div>')
    b += ('<div class="row between" style="margin-top:4px;background:var(--mint);border-radius:16px;padding:12px 14px"><span style="font-weight:800;font-size:14px">Cada persona paga</span><span class="pop" style="font-weight:700;font-size:18px;color:var(--green)">$4.00</span></div></div></div>')
    b += f'<div class="px row" style="gap:8px;margin-top:12px;justify-content:center"><span class="tiny" style="font-size:12px">Transcrito en el dispositivo · ¿Más precisión?</span><span class="pro">{ic("crown",11,"#fff",2.6)} PRO</span></div>'
    b += (f'<div class="px" style="position:absolute;bottom:34px;left:0;right:0"><div class="row" style="gap:12px;margin-bottom:12px"><div class="btn ghost" style="flex:1;height:44px;font-size:14px;border-radius:16px">{ic("edit",17)} Editar</div><div class="btn ghost" style="flex:1;height:44px;font-size:14px;border-radius:16px">{ic("mic",17)} Volver a dictar</div></div>'
          f'<div class="btn">{ic("check",21,"#fff",2.8)} Confirmar gasto</div></div>')
    return b + homeind()

# ---------- 09 Liquidación ----------
TR = [('Diego','Sofi','$34.60'),('Carla','Sofi','$29.00'),('Ana','Sofi','$11.20'),('Laura','Sofi','$10.60'),('Ana','Luis','$2.40')]
def s09():
    b = status()
    b += f'<div class="px row between" style="margin-top:6px"><div class="iconbtn">{ic("back",22)}</div><div class="h2" style="font-size:18px">Liquidación</div><div class="iconbtn">{ic("share",20)}</div></div>'
    b += ('<div class="px" style="margin-top:12px"><div style="position:relative;overflow:hidden;border-radius:28px;background:var(--mint);padding:16px 20px">'
          f'<div style="position:absolute;right:4px;bottom:-14px">{coins(92)}</div>'
          '<div class="pop" style="font-weight:700;font-size:22px;letter-spacing:-.4px;line-height:1.2">¿Quién le paga<br>a quién? 🤝</div>'
          '<div class="small" style="margin-top:6px">Playa El Tunco · Total <b style="color:var(--ink)">$202.00</b></div>'
          f'<div class="tag g" style="margin-top:10px;background:#fff">{ic("sparkle",13,"var(--green)",2.4)} Solo 5 transferencias</div></div></div>')
    b += '<div class="px" style="margin-top:14px">'
    for f, t, amt in TR:
        me = f == 'Laura'
        bg = 'background:var(--peach);box-shadow:inset 0 0 0 2px var(--accent);' if me else ''
        who = f'<b>Tú</b> le pagas a <b>{t}</b>' if me else f'<b>{f}</b> le paga a <b>{t}</b>'
        action = (f'<div class="btn" style="height:34px;border-radius:12px;font-size:12.5px;padding:0 12px;box-shadow:none">Pagar</div>' if me else
                  f'<div style="width:34px;height:34px;border-radius:50%;background:var(--cream);display:flex;align-items:center;justify-content:center;box-shadow:inset 0 0 0 1.5px var(--line);flex:none">{ic("check",16,"var(--ink3)",2.6)}</div>')
        b += (f'<div class="card row" style="padding:10px 14px;gap:10px;border-radius:22px;margin-bottom:8px;{bg}">'
              f'<div class="row" style="gap:0;flex:none">{av(f,36)}<div style="width:20px;display:flex;justify-content:center;color:var(--ink3)">{ic("arrow",15,"var(--ink3)",2.4)}</div>{av(t,36)}</div>'
              f'<div style="flex:1;min-width:0;margin-left:4px"><div style="font-size:13px;line-height:1.25;white-space:nowrap">{who}</div><div class="pop" style="font-weight:700;font-size:18px;margin-top:1px">{amt}</div></div>{action}</div>')
    b += '</div>'
    b += (f'<div class="px"><div class="row" style="gap:12px;background:var(--sun);border-radius:20px;padding:12px 14px"><div class="etile" style="width:40px;height:40px;background:#fff;font-size:19px">💵</div>'
          '<div style="flex:1"><div style="font-weight:800;font-size:13.5px">Efectivo sobrante: $52.00</div><div class="tiny" style="font-size:12px;color:var(--ink2)">Se devuelven: Ana $39.00 · Luis $13.00</div></div></div></div>')
    b += f'<div class="px" style="position:absolute;bottom:34px;left:0;right:0"><div class="btn">{whatsapp(22,True)} Compartir resumen</div></div>' + homeind()
    return b

# ---------- 10 Efectivo del grupo ----------
def s10():
    b = status()
    b += f'<div class="px row between" style="margin-top:6px"><div class="iconbtn">{ic("back",22)}</div><div class="h2" style="font-size:18px">Efectivo del grupo</div><div class="iconbtn">{ic("help",20)}</div></div>'
    b += ('<div class="px" style="margin-top:14px"><div style="position:relative;border-radius:30px;background:var(--mint);padding:16px 20px 16px;overflow:hidden">'
          f'<div style="position:absolute;right:4px;top:6px">{wallet_cash(124)}</div>'
          '<div class="tag" style="background:#fff;color:var(--green)">💵 Efectivo del grupo</div>'
          '<div class="small" style="margin-top:12px">Efectivo disponible</div><div class="pop" style="font-weight:700;font-size:38px;letter-spacing:-1px;line-height:1.15">$52.00</div>'
          '<div class="small">de $80.00 reunidos</div>'
          '<div style="height:12px;border-radius:6px;background:#fff;margin-top:14px;overflow:hidden;display:flex"><div style="width:65%;background:var(--green);border-radius:6px"></div></div>'
          '<div class="row between" style="margin-top:7px"><span class="tiny" style="color:var(--green)">Queda 65%</span><span class="tiny">Gastado $28.00</span></div>'
          f'<div class="row" style="gap:8px;margin-top:10px;background:rgba(255,255,255,.7);border-radius:14px;padding:6px 10px">{av("Ana",26)}<span style="font-size:13px;font-weight:700">Lo guarda <b>Ana</b></span></div></div></div>')
    b += '<div class="px sechead" style="margin-top:14px;margin-bottom:10px"><div class="h3">¿Quién aportó?</div><span class="link">+ Aporte</span></div><div class="px">'
    for n, how, amt, pct in [('Ana','🏧 Retiro en cajero','$60.00','75%'),('Luis','💵 Efectivo de su bolsa','$20.00','25%')]:
        b += (f'<div class="card row" style="padding:10px 14px;gap:12px;border-radius:22px;margin-bottom:8px">{av(n,40)}<div style="flex:1"><div style="font-weight:800;font-size:15px">{n}</div><div class="tiny" style="font-size:12px">{how}</div></div>'
              f'<div style="text-align:right"><div class="pop" style="font-weight:700;font-size:16px">{amt}</div><div class="tiny">{pct} del fondo</div></div></div>')
    b += '</div><div class="px sechead" style="margin-top:8px;margin-bottom:10px"><div class="h3">Pagado en efectivo</div><span class="small" style="font-weight:800">$28.00</span></div><div class="px">'
    b += exp_row(EXP[1]).replace('💵 Efectivo','5 personas').replace('Efectivo del grupo · 5 personas','Hoy · 1:20 p.m.') + exp_row(EXP[2]).replace('💵 Efectivo','5 personas').replace('Efectivo del grupo · 5 personas','Hoy · 3:05 p.m.')
    b += '</div>'
    b += (f'<div class="row" style="position:absolute;bottom:34px;left:20px;right:20px;gap:12px"><div class="btn ghost" style="flex:1;font-size:15px">{ic("plus",19)} Aporte</div>'
          f'<div class="btn" style="flex:1.4;font-size:15px">{ic("cash",20,"#fff")} Gasto en efectivo</div></div>' + homeind())
    return b

# ---------- 11 Resumen compartir ----------
def s11():
    b = status()
    b += f'<div class="px row between" style="margin-top:6px"><div class="iconbtn">{ic("close",22)}</div><div class="h2" style="font-size:18px">Resumen del viaje</div><div class="iconbtn">{ic("download",20)}</div></div>'
    b += ('<div style="margin:16px 34px 0;background:#fff;border-radius:30px;overflow:hidden;box-shadow:0 20px 44px rgba(31,42,59,.14);transform:rotate(-1.2deg)">'
          f'<div style="height:112px;position:relative">{beach()}<div style="position:absolute;left:14px;bottom:10px" class="tag"><span style="background:rgba(255,255,255,.95);padding:4px 10px;border-radius:10px;font-weight:900">2–4 oct 2026</span></div></div>'
          '<div style="padding:14px 18px 16px"><div class="row between"><div class="pop" style="font-weight:700;font-size:19px;letter-spacing:-.3px">Playa El Tunco 🌊</div></div>'
          f'<div class="row between" style="margin-top:8px"><div>{stack(ALL,24)}</div><div style="text-align:right"><div class="tiny">Total del viaje</div><div class="pop" style="font-weight:700;font-size:22px;color:var(--accent)">$202.00</div></div></div>'
          '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:10px">'
          + ''.join(f'<div class="row" style="gap:6px;background:{bg};border-radius:12px;padding:6px 8px;font-size:11.5px;font-weight:800"><span>{e}</span><span style="flex:1">{t}</span><span>{a}</span></div>' for e,t,a,bg in
                    [('🏠','Hospedaje','$120','var(--sky)'),('🎟️','Diversión','$30','var(--lav)'),('🍽️','Comida','$28','var(--sun)'),('⛽','Transporte','$24','var(--peach)')]) +
          '</div><div style="font-weight:900;font-size:12px;margin-top:12px;color:var(--ink2);letter-spacing:.3px">QUIÉN LE PAGA A QUIÉN</div>'
          + ''.join(f'<div class="row" style="gap:6px;padding:4px 0;font-size:12.5px;font-weight:700;{"border-top:1px dashed var(--line)" if i else ""}">{av(f,20)}<span>{f}</span><span style="color:var(--ink3)">→</span>{av(t,20)}<span style="flex:1">{t}</span><b class="pop" style="font-size:13px">{a}</b></div>' for i,(f,t,a) in enumerate(TR)) +
          f'<div class="row between" style="margin-top:10px;padding-top:10px;border-top:1px solid var(--line)"><div class="row" style="gap:6px">{logo(20)}<span class="pop" style="font-weight:700;font-size:12px">Hecho con Kaval</span></div><span class="tiny">💵 Efectivo sobrante: $52</span></div></div></div>')
    b += f'<div class="row" style="justify-content:center;gap:6px;margin-top:22px">{ic("image",15,"var(--ink2)")}<span class="small" style="font-size:12.5px">Vista previa · imagen 1080 × 1350 lista para WhatsApp</span></div>'
    b += (f'<div class="px" style="position:absolute;bottom:34px;left:0;right:0"><div class="btn" style="background:#25D366;box-shadow:0 10px 22px rgba(37,211,102,.32)">{whatsapp(24,True)} Compartir por WhatsApp</div>'
          f'<div class="row" style="gap:10px;margin-top:12px"><div class="btn ghost" style="flex:1;height:48px;font-size:13.5px">{ic("image",17)} Imagen</div><div class="btn ghost" style="flex:1;height:48px;font-size:13.5px">{ic("copy",17)} Texto</div><div class="btn ghost" style="flex:1;height:48px;font-size:13.5px;gap:6px">{ic("file",17)} PDF <span class="pro" style="height:18px;padding:0 5px;font-size:9px">PRO</span></div></div></div>')
    return b + homeind()

# ---------- 12 Invitar ----------
def s12():
    b = status()
    b += f'<div class="px row between" style="margin-top:6px"><div class="iconbtn">{ic("back",22)}</div><div class="h2" style="font-size:18px">Invitar al evento</div><div style="width:44px"></div></div>'
    b += ('<div class="px" style="margin-top:12px"><div class="card" style="padding:14px 18px 16px;border-radius:30px;text-align:center;background:linear-gradient(180deg,#FFE9DE 0%,#FFFFFF 62%)">'
          '<div class="row" style="gap:14px;align-items:center;text-align:left">' + envelope(92) +
          '<div><div class="h3" style="font-size:17px;line-height:1.25">¡Suma a tu grupo a Playa El Tunco!</div><div class="small" style="margin-top:4px">Con el código se unen y ven los gastos al instante.</div></div></div>'
          '<div class="tiny" style="margin-top:10px;letter-spacing:.8px">CÓDIGO DEL EVENTO</div>'
          f'<div class="row" style="justify-content:center;gap:10px;margin-top:6px"><div class="pop" style="font-weight:700;font-size:30px;letter-spacing:4px">TUNCO-7K2</div><div class="iconbtn" style="width:40px;height:40px;border-radius:14px;background:var(--accent-s);color:var(--accent-d);box-shadow:none">{ic("copy",19)}</div></div>'
          f'<div class="row" style="justify-content:center;gap:16px;margin-top:12px"><div style="padding:10px;background:#fff;border-radius:18px;box-shadow:inset 0 0 0 1.5px var(--line)">{qr(92)}</div>'
          '<div style="text-align:left"><div class="tag n">⏳ Expira en 7 días</div><div class="small" style="margin-top:8px;max-width:130px;font-size:12.5px">Escanéalo desde la app o usa el enlace.</div></div></div>'
          f'<div class="row" style="gap:10px;margin-top:12px"><div class="btn" style="flex:1.3;height:46px;font-size:14px;background:#25D366;box-shadow:none">{whatsapp(19,True)} WhatsApp</div><div class="btn ghost" style="flex:1;height:46px;font-size:14px">{ic("link",17)} Enlace</div></div></div></div>')
    b += '<div class="px sechead" style="margin-top:16px;margin-bottom:8px"><div class="h3">Integrantes <span style="color:var(--ink3)">(6)</span></div><span class="link">+ Por nombre</span></div><div class="px"><div class="card" style="padding:4px 16px;border-radius:24px">'
    mem = [(['Laura'],'Laura','Tú · Admin','tag a','Admin'),(['Ana','Luis','Sofi'],'Ana, Luis y Sofi','Se unieron con código','tag g','3 unidos ✓'),(['Diego'],'Diego','Invitado (solo nombre)','tag n','Invitar'),(['Carla'],'Carla','Invitación enviada','tag n','Pendiente')]
    for i,(ns,n,s,c,t) in enumerate(mem):
        b += (f'<div class="row" style="gap:12px;padding:7px 0;{"border-top:1px solid var(--line)" if i else ""}">{stack(ns,34) if len(ns)>1 else av(ns[0],36)}<div style="flex:1"><div style="font-weight:800;font-size:14.5px">{n}</div><div class="tiny" style="font-size:11.5px">{s}</div></div>'
              f'<span class="{c}">{t}</span></div>')
    b += '</div></div>' + homeind()
    return b

# ---------- 13 Perfil ----------
def s13():
    b = status()
    b += f'<div class="px row between" style="margin-top:6px"><div class="h2" style="font-size:22px">Perfil</div><div class="iconbtn">{ic("sliders",20)}</div></div>'
    b += (f'<div class="px" style="margin-top:12px"><div class="card row" style="padding:14px 16px;gap:14px;border-radius:26px">{av("Laura",58)}'
          '<div style="flex:1"><div class="h3" style="font-size:18px">Laura Angel</div><div class="small">laura.angel@email.com</div>'
          f'<div class="tag g" style="margin-top:6px">{ic("cloudcheck",14,"var(--green)",2.4)} Sincronizado hace 1 min</div></div>{ic("chev",20,"var(--ink3)")}</div></div>')
    b += ('<div class="px" style="margin-top:14px"><div style="position:relative;overflow:hidden;border-radius:26px;padding:14px 18px;background:linear-gradient(135deg,#2B3550,#1F2A3B);color:#fff">'
          '<div style="position:absolute;right:-30px;top:-40px;width:130px;height:130px;border-radius:50%;border:18px solid rgba(255,181,71,.14)"></div>'
          f'<div class="row" style="gap:8px"><span class="pro" style="height:24px;font-size:12px;padding:0 10px">{ic("crown",13,"#fff",2.6)} PRO</span><span class="pop" style="font-weight:600;font-size:16px">Kaval Pro</span></div>'
          '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px 10px;margin-top:10px;font-size:12.5px;font-weight:700;opacity:.92">'
          '<span>🎙️ Voz en la nube</span><span>📄 Exportar PDF / Excel</span><span>📊 Estadísticas</span><span>🚫 Sin anuncios</span></div>'
          '<div class="btn" style="height:42px;border-radius:14px;margin-top:12px;font-size:14px;box-shadow:none">Probar 7 días gratis</div></div></div>')
    b += '<div class="px" style="margin-top:14px"><div class="card" style="padding:4px 16px;border-radius:24px">'
    def item(icn, label, right, first=False, color='var(--ink)', bg='var(--cream)'):
        return (f'<div class="row" style="gap:12px;padding:8px 0;{"" if first else "border-top:1px solid var(--line)"}"><div style="width:34px;height:34px;border-radius:12px;background:{bg};display:flex;align-items:center;justify-content:center;flex:none">{ic(icn,18,color)}</div>'
                f'<span style="flex:1;font-weight:800;font-size:14.5px;color:{color}">{label}</span>{right}</div>')
    b += item('globe','Idioma','<div class="seg" style="padding:3px;border-radius:12px;width:104px"><div class="on" style="height:28px;border-radius:9px;font-size:12.5px">ES</div><div style="height:28px;font-size:12.5px">EN</div></div>', True)
    b += item('dollar','Moneda','<span class="small" style="font-weight:800">USD ($)</span>')
    b += item('cloudcheck','Sincronizar en la nube','<div class="toggle"></div>')
    b += item('shield','Privacidad y datos', ic('chev',18,'var(--ink3)'))
    b += item('logout','Cerrar sesión', ic('chev',18,'var(--ink3)'))
    b += item('trash','Eliminar cuenta', ic('chev',18,'var(--red)'), color='var(--red)', bg='var(--red-s)')
    b += '</div></div>'
    return b + nav('Perfil')

SCREENS = [
 ('01_onboarding', 'Onboarding / Bienvenida', s01, 'var(--cream)'),
 ('02_login_registro', 'Login / Registro', s02, 'var(--cream)'),
 ('03_inicio', 'Inicio', s03, 'var(--cream)'),
 ('04_crear_evento', 'Crear evento + integrantes', s04, 'var(--cream)'),
 ('05_detalle_evento', 'Detalle del evento', s05, 'var(--cream)'),
 ('06_agregar_gasto_manual', 'Agregar gasto manual', s06, 'var(--cream)'),
 ('07_dictar_gasto', 'Dictar gasto (grabando)', s07, 'linear-gradient(180deg,#FFE6D8 0%,#FFF8F0 70%)'),
 ('08_confirmar_gasto_dictado', 'Confirmar gasto dictado', s08, 'var(--cream)'),
 ('09_liquidacion', 'Quién le paga a quién', s09, 'var(--cream)'),
 ('10_efectivo_del_grupo', 'Efectivo del grupo', s10, 'var(--cream)'),
 ('11_resumen_compartir', 'Resumen para compartir', s11, 'var(--mint)'),
 ('12_invitar_evento', 'Invitar al evento', s12, 'var(--cream)'),
 ('13_perfil_ajustes', 'Perfil / Ajustes', s13, 'var(--cream)'),
]
if __name__ == '__main__':
    import sys
    for fn, title, f, bg in SCREENS:
        open(f'screens/{fn}.html','w').write(page(f'Kaval · {title}', f(), bg))
    print('written', len(SCREENS))
